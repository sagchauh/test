import mongoose, { Schema } from "mongoose"

const noticeSchema = new Schema({
    title:{
        type:"string",
        require:true,
    },
    date:{
        type:Date,
        require:true,
    }
}, { timestamps: true })

export default mongoose.model("Notice", noticeSchema)