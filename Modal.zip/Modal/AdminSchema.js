import mongoose, { Schema } from "mongoose";

const AdminSchema = new Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },
    role: {
        type: String,
        default: "Admin"
    },
    password: {
        type: String,
        required: true,
    },
    number: {
        type: String,
        required: true,
    },
    otp: {
        type: String,
        default: null,
    },
    emailotp: {
        type: String,
        default: null,
    },
    isverified: {
        type: Boolean,
        default: false,
    },
    image: {
        type: String,
        required: true,
    }
});

export default mongoose.model("Admin", AdminSchema);
