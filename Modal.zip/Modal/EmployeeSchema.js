import mongoose, { Schema } from "mongoose";

const employeeSchema = new Schema({
    name: {
        type: "string",
        required: true,
    },
    number: {
        type: "string",
        required: true,
    },
    email: {
        type: "string",
        required: true,
    },
    role: {
        type: "string",
        default: "Employee"
    },
    image:{
        type: String,
        required: true,
    },
    password: {
        type: "string",
        required: true,
    },
    intime: [
        {
            date: {
                type: Date,
                required: true,
            },
            day:{
                type: "string",
                required: true,
            },
            time: {
                type: "string",
                required: true,
            }
        }
    ],
    outtime: [
        {
            date: {
                type: Date,
                required: true,
            },
            day:{
                type: "string",
                required: true,
            },
            time: {
                type: "string",
                required: true,
            }
        }
    ]
})

export default mongoose.model("Employee", employeeSchema)