import mongoose, { Schema } from "mongoose";

const trainingmodeSchema = new Schema({
    trainingmode: {
        type: String,
        required: true
    }
})

export default mongoose.model("Trainingmode", trainingmodeSchema)