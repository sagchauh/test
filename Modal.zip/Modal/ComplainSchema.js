import mongoose, { Schema } from "mongoose";

const complainSchema = new Schema({
    complain: {
        type: String,
        required: true,
    },
    date: {
        type: Date,
        required: true,
    },
    studentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Student',
        required: true,
    },
});

export default mongoose.model("Complain", complainSchema);
