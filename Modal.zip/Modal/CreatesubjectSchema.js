import mongoose, { Schema } from "mongoose";

const createsubjectSchema = new Schema({
    createsubject: {
        type: String,
        required: true,
    },
    students: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Student',
        required: true,
    }],
    assignedteacher: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Teacher',
        required: true,
    },
    date: {
        type: Date,
        required: true,
    }
});

export default mongoose.model("createsubject", createsubjectSchema);
