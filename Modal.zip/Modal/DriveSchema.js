import mongoose from "mongoose";

const DriveSchema = new mongoose.Schema({
    drivelink: {
        type: String,
        required: true
    },
    githublink: {
        type: String,
        required: true
    },
    createsubject: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'createsubject',
        required: true
    },
    date: {
        type: Date,
        require: true,
    }
});

export default mongoose.model("Drive", DriveSchema);
