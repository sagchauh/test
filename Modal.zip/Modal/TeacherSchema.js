import mongoose, { Schema } from "mongoose"

const TeacherSchema = new Schema({
    name: {
        type: "string",
        require: true,
    },
    email: {
        type: "string",
        require: true,
    },
    role: {
        type: "string",
        default: "Teacher",
    },
    password: {
        type: "string",
        require: true,
    },
    image: {
        type: String,
        required: true,
    },
    course: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Course',
        require: true,
    },
})

export default mongoose.model("Teacher", TeacherSchema)