import mongoose, { Schema } from "mongoose"

const StudentSchema = new Schema({
    name: {
        type: "string",
        require: true,
    },
    email: {
        type: "string",
        require: true,
    },
    number: {
        type: "string",
        require: true,
    },
    fees: {
        type: "number",
        default: 0
    },
    trainingmode: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Trainingmode',
        require: true,
    },
    trainingmodule: {
        type: "string",
        require: true,
    },
    role: {
        type: "string",
        default: "student"
    },
    password: {
        type: "string",
        require: true,
    },
    batch: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Batch',
        require: true,
    },
    course: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Course',
        require: true,
    },
    assignedteacher: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Teacher',
        require: true,
    },
    date: {
        type: Date,
        required: true,
    },
    uploadlink: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Drive',
            require: true,
        }
    ],
    testresult: [
        {
            
            markobtained: {
                type: Number,
                default: 0
            },
            uploadmarks: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Drive',
            },
        }
    ],
    studenattendance: [
        {
            subjectstatus: {
                type: "string",
                // enum: ['present', 'absent'],
                require: true,
            },
            date: {
                type: Date,
                require: true,
            }
        }
    ],
    image: {
        type: String,
        required: true,
    },
    createsubject: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'createsubject',
            required: true,
        }
    ],
    performance: [
        {
            date: {
                type: Date,
                require: true,
            },
            performancestatus: {
                type: String,
                required: true,
            },
            subject: {
                type: String,
                required: true,
            }
        }
    ],
    termscondition: {
        type: Boolean,
        default: false,
    }
})

export default mongoose.model("Student", StudentSchema)