import mongoose, { Schema } from "mongoose";

const SubSchema = new Schema({
    subjectname: {
        type: "string",
        require: true,
    },
})

export default mongoose.model("Subject", SubSchema)