import mongoose, { Schema } from "mongoose"


const BatchSchema = new Schema({
    batch: {
        type: "string",
        require: true
    },
    date: { 
        type: Date,
        require: true,
    },
    maxStudents: {
        type: Number,
        default: 0
    },
    offlineEnrollment: {
        type: Number,
        default: 0
    },
    onlineEnrollment: {
        type: Number,
        default: 0
    },
    course: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Course',
        require: true,
    }
})

export default mongoose.model("Batch", BatchSchema)