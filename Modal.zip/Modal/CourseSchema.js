import mongoose, { Schema } from "mongoose";

const CourseSchema = new Schema({
    course: {
        type: String,
        required: true
    },
    teachers: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Teacher'
    }],
    trainingmode: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Trainingmode'
    }]
})

export default mongoose.model("Course", CourseSchema)