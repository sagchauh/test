import express from "express";
import {adminloginmiddlware, adminregistermiddlware, deleteadminmiddlware, forgetpassverifyotpmiddlware, forgetpasswordmiddlware, resetpasswordmiddlware, showsingleadmindatamiddlware, updateadmindatamiddlware, verifyotpmiddlware } from "../Middleware/Adminmiddlware.js";
import { adminlist, adminlogin, adminregister, deleteadmin, forgetpassverifyotp, forgetpassword, resetpassword, showsingleadmindata, updateadmindata, verifyotp } from "../Controller/AdminController.js";
import { coursedatamiddlware, dropdowncoursemiddlware } from "../Middleware/Coursedatamiddlware.js";
import { coursedata, dropdowncourse, getallcourse, getallcoursedata } from "../Controller/CoursedataController.js";
import { batchdatamiddlware, dropdownbatchmiddlware } from "../Middleware/Batchdatamiddlware.js";
import { batchdata, dropdownbatch, getallbatch } from "../Controller/Batchdatacontroller.js";
import { assignedteachermiddlware, teacherloginmiddlware, teacherregistermiddlware, teacherstudentdatamiddlware } from "../Middleware/Teachermiddlware.js";
import { assignedteacher, teacherlogin, teacherregister, teacherstudentdata } from "../Controller/TeacherController.js";
import { acceptpolicymiddlware, attendacetrackmiddlware, attendancemiddlware, createtestmiddlware, deletestudentmiddlware, editattendancemiddlware, editfinalmarksamiddlware, editmarksdatamiddlware, editperformancemiddlware, fetchteachnamemiddlware, findupdatedatamiddlware, getcurrentstudentmiddlware, getrespectiveteachernamesmiddlware, markperformancemiddlware, multipleperformancemiddlware, showparticularstudentdatamiddlware, singlestudentdatamiddlware, studentdatamidlware, studentloginmiddlware, studentregistermiddlware, subjectstudentdatamidlware, updatemarksmiddlware, updatestudentdatamiddlware } from "../Middleware/Studentmiddlware.js";
import { acceptpolicy, attendace, attendacetrack, createtest, deletestudent, editattendance, editfinalmarks, editmarksdata, editperformance, fetchteachname, findupdatedata, getallstudentdata, getbatchwisedata, getcurrentstudent, getdatacoursewise, getrespectiveteachernames, markperformance, multipleperformance, multiplestudentattendance, showparticularstudentdata, singlestudentdata, studentdata, studentdetails, studentlogin, studentregister, subjectstudentdata, updatemarks, updatestudentdata } from "../Controller/StudentController.js";
import { showallsubject, subjectenter } from "../Controller/SubController.js";
import { addnoticemiddlware } from "../Middleware/Noticemiddlware.js";
import { addnotice, shownotice } from "../Controller/NoticeController.js";
import { addcomplainmiddlware } from "../Middleware/Complainmiddlware.js";
import { addcomplain, deletecomplain, showcomplain } from "../Controller/ComplainController.js";
import { uploaddrivelinkmiddlware } from "../Middleware/Drivemiddlware.js";
import { uploaddrivelink } from "../Controller/DriveController.js";
import { trainingmodemiddlware } from "../Middleware/Trainingmodemiddlware.js";
import { getalltrainingmode, trainingmode } from "../Controller/TrainingmodeController.js";
import { deleteemployeemiddlware, editintimemiddlware, editouttimemiddlware, employeeloginmiddlware, employeeregistermiddlware, intimemiddlware, outtimemiddlware, showsingleemployeemiddlware, updateemployeemiddlware } from "../Middleware/Employeemiddlware.js";
import { deleteemployee, editintime, editouttime, employeelogin, employeeregister, intime, outtime, showemployeelist, showsingleemployee, updateemployee } from "../Controller/EmployeeController.js";


import multer from 'multer';
import path from 'path';
import { verify } from "crypto";



const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now();
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });


const route = express.Router();

// Admin-Routes
route.post("/adminregister", upload.single('image'), adminregistermiddlware, adminregister)
route.post("/adminlogin", adminloginmiddlware, adminlogin);
route.post("/verifyotp", verifyotpmiddlware, verifyotp);
route.post("/adminlist", adminlist);
route.post("/showsingleadmindata", showsingleadmindatamiddlware, showsingleadmindata);
route.post("/updateadmindata", upload.single('image'), updateadmindatamiddlware, updateadmindata);
route.post("/deleteadmin", deleteadminmiddlware, deleteadmin)

//admin forget password
route.post("/forgetpassword", forgetpasswordmiddlware, forgetpassword);
route.post("/forgetpassverifyotp", forgetpassverifyotpmiddlware, forgetpassverifyotp);
route.post("/resetpassword", resetpasswordmiddlware, resetpassword);

//Course
route.post("/coursedata", coursedatamiddlware, coursedata);
route.post("/getallcourse", getallcourse);
route.post("/dropdowncourse", dropdowncoursemiddlware, dropdowncourse);

//Batch
route.post("/batchdata", batchdatamiddlware, batchdata);
route.post("/getallbatch", getallbatch);
route.post("/dropdownbatch", dropdownbatchmiddlware, dropdownbatch);

//Trainingmode
route.post("/trainingmode", trainingmodemiddlware, trainingmode);
route.post("/getalltrainingmode", getalltrainingmode)

//Teacher-Routes
route.post("/teacherregister", upload.single('image'), teacherregistermiddlware, teacherregister);
route.post("/teacherlogin", teacherloginmiddlware, teacherlogin);
route.post("/assignedteacher", assignedteachermiddlware, assignedteacher);
route.post("/teacherstudentdata", teacherstudentdatamiddlware, teacherstudentdata);

//Student-Routes
route.post("/studentregister", upload.single('image'), studentregistermiddlware, studentregister);
route.post("/getrespectiveteachernames", getrespectiveteachernamesmiddlware, getrespectiveteachernames);

route.post("/acceptpolicy", acceptpolicymiddlware, acceptpolicy)

route.post("/studentlogin", studentloginmiddlware, studentlogin);
route.post("/getcurrentstudent", getcurrentstudentmiddlware, getcurrentstudent)
route.post("/singlestudentdata", singlestudentdatamiddlware, singlestudentdata);
route.post("/deletestudent", deletestudentmiddlware, deletestudent);
route.post("/fetchteachname", fetchteachnamemiddlware, fetchteachname);

route.post("/updatestudentdata", upload.single('image'), updatestudentdatamiddlware, updatestudentdata);

route.post("/getallstudentdata", getallstudentdata);
route.post("/showparticularstudentdata", showparticularstudentdatamiddlware, showparticularstudentdata);
route.post("/studentdata", studentdatamidlware, studentdata);
route.post("/subjectstudentdata", subjectstudentdatamidlware, subjectstudentdata);

// filter data-Routes
route.post("/getallcoursedata", getallcoursedata);
route.post("/getdatacoursewise", getdatacoursewise);
route.post("/getbatchwisedata", getbatchwisedata)

//Subject-Routes    
route.post("/subjectenter", subjectenter);
route.post("/showallsubject", showallsubject);

//Marks-obtained
route.post("/updatemarks", updatemarksmiddlware, updatemarks);
route.post("/findupdatedata", findupdatedatamiddlware, findupdatedata);
route.post("/editmarksdata", editmarksdatamiddlware, editmarksdata);
route.post("/editfinalmarks", editfinalmarksamiddlware, editfinalmarks)

// student-attendace
route.post("/attendace", attendancemiddlware, attendace)
route.post("/attendacetrack", attendacetrackmiddlware, attendacetrack);
route.post("/studentdetails", studentdetails);
route.post("/multiplestudentattendance", multiplestudentattendance);
route.post("/editattendance", editattendancemiddlware, editattendance);

//Notice
route.post("/addnotice", addnoticemiddlware, addnotice);
route.post("/shownotice", shownotice);

//Complain
route.post("/addcomplain", addcomplainmiddlware, addcomplain);
route.post("/showcomplain", showcomplain);
route.post("/deletecomplain", deletecomplain);

//Drive
route.post("/uploaddrivelink", uploaddrivelinkmiddlware, uploaddrivelink);

//test-subject
route.post("/createtest", createtestmiddlware, createtest);

//performance
route.post("/markperformance", markperformancemiddlware, markperformance);
route.post("/editperformance", editperformancemiddlware, editperformance);
route.post("/multipleperformance", multipleperformancemiddlware, multipleperformance);

//Employee
route.post("/employeeregister", upload.single('image'), employeeregistermiddlware, employeeregister);
route.post("/employeelogin", employeeloginmiddlware, employeelogin);
route.post("/updateemployee", updateemployeemiddlware, updateemployee);
route.post("/deleteemployee", deleteemployeemiddlware, deleteemployee);
route.post("/showemployeelist", showemployeelist);
route.post("/showsingleemployee", showsingleemployeemiddlware, showsingleemployee)

//Employee-Attendance
route.post("/intime", intimemiddlware, intime);
route.post("/outtime", outtimemiddlware, outtime);
route.post("/editintime", editintimemiddlware, editintime);
route.post("/editouttime", editouttimemiddlware, editouttime);


export default route;