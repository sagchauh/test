import validator from "validator";
import Student from "../Modal/StudentSchema.js";

export const studentregistermiddlware = async (req, res, next) => {
    const { name, email, password, number, fees, trainingmode, trainingmodule, course, batch, assignedteacher } = req.body;


    if (!name) return res.send("name is required");
    if (!email) return res.send("email is required");
    if (!number) return res.send("number is required");
    if (!fees) return res.send("fees is required")
    if (!password) return res.send("password is required");
    if (!course) return res.send("course is required");
    if (!batch) return res.send("batch is required");
    if (!assignedteacher) return res.send("assignedteacher is required");
    if (!trainingmode) return res.send("trainingmode is required")
    if (!trainingmodule) return res.send("trainingmodule is required");

    if (!validator.isEmail(email)) {
        return res.status(201).json({ error: "Invalid email format" });
    }

    const isEmailExist = await Student.findOne({ email });
    if (isEmailExist) {
        return res.status(400).json({ error: "Email already exists" });
    }

    next()
}

export const getrespectiveteachernamesmiddlware = (req, res, next) => {

    const {date, courseId } = req.body;
    if (!courseId) return res.send("courseId is required");
    if (!date) return res.send("date is required")

    next()
}

export const fetchteachnamemiddlware = (req, res, next) => {

    const { courseId } = req.body;
    if (!courseId) return res.send("courseId is required")

    next()
}

export const acceptpolicymiddlware = (req, res, next) => {
    const { email } = req.body;
    if (!email) return res.send("email is required")

    next()
}

export const studentloginmiddlware = (req, res, next) => {
    const { email, password } = req.body;

    if (!email) return res.send("email is required")
    if (!password) return res.send("password is required");
    next()
}


export const getcurrentstudentmiddlware = (req, res, next) => {
    const { studentjwt } = req.body

    if (!studentjwt) return res.send("studentjwt is required")
    next()
}


export const singlestudentdatamiddlware = (req, res, next) => {
    const { _id } = req.body;
    if (!_id) return res.send("_id is required");
    next()
}

export const updatestudentdatamiddlware = (req, res, next) => {
    const { _id } = req.body;
    console.log(_id, "updatestudentdatamiddlware")
    if (!_id) return res.send("_id is required");

    next()
}

export const updatemarksmiddlware = (req, res, next) => {
    const { drivedataId, markobtained, _id } = req.body;
    if (!drivedataId) return res.send("drivedataId is required")
    if (!markobtained) return res.send("markobtained is required");
    if (!_id) return res.send("_id is required");

    next()
}

export const findupdatedatamiddlware = (req, res, next) => {
    const { _id } = req.body;
    if (!_id) return res.send("_id is required");

    next()
}

export const attendancemiddlware = (req, res, next) => {

    const { subjectstatus, date, _id } = req.body;
    if (!subjectstatus) return res.send("subjectstatus is required");
    if (!date) return res.send("date is required");
    if (!_id) return res.send("_id is required");

    next()
}

export const showparticularstudentdatamiddlware = (req, res, next) => {
    const { _id } = req.body
    if (!_id) return res.send("_id is required")

    next()
}

export const studentdatamidlware = (req, res, next) => {

    const { _id } = req.body
    if (!_id) return res.send("_id is required")

    next()
}

export const attendacetrackmiddlware = (req, res, next) => {

    const { _id } = req.body
    if (!_id) return res.send("_id is required")

    next()
}

export const createtestmiddlware = (req, res, next) => {

    const { studentIds, createsubject, date } = req.body;

    if (!studentIds) return res.send("studentIds is required")
    if (!createsubject) return res.send("createsubject is required")
    if (!date) return res.send("date is required")

    next()
}

export const subjectstudentdatamidlware = (req, res, next) => {

    const { _id } = req.body
    if (!_id) return res.send("_id is required")

    next()
}

export const editmarksdatamiddlware = (req, res, next) => {
    const { _id } = req.body
    if (!_id) return res.send("_id is required")

    next()
}

export const editfinalmarksamiddlware = (req, res, next) => {
    const { _id, markobtained } = req.body
    if (!_id) return res.send("_id is required")
    // if (!markobtained) return res.send("markobtained is required")

    next()
}

export const deletestudentmiddlware = (req, res, next) => {
    const { _id } = req.body
    if (!_id) return res.send("_id is required")

    next()
}

export const editattendancemiddlware = (req, res, next) => {
    const { _id, subjectstatus, date } = req.body;
    if (!_id) return res.send("_id is required");
    if (!subjectstatus) return res.send("subjectstatus is required");
    if (!date) return res.send("date is required");

    next()
}

export const markperformancemiddlware = (req, res, next) => {

    const { _id, performancestatus, date } = req.body;

    if (!_id) return res.send("_id is required");
    if (!performancestatus) return res.send("performancestatus is required");
    if (!date) return res.send("date is required");

    next()
}

export const editperformancemiddlware = (req, res, next) => {
    const { _id, performancestatus, date } = req.body;
    if (!_id) return res.send("_id is required");
    if (!performancestatus) return res.send("performancestatus is required");
    if (!date) return res.send("date is required");

    next()
}

export const multipleperformancemiddlware = (req, res, next) => {
    const { _id, performancestatus, date, subject } = req.body;
    if (!_id) return res.send("_id is required");
    if (!performancestatus) return res.send("performancestatus is required");
    if (!date) return res.send("date is required");
    if (!subject) return res.send("subject is required");

    next()
}