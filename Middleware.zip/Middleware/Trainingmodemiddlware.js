export const trainingmodemiddlware = (req, res, next) => {
    const { trainingmode } = req.body

    if (!trainingmode) return res.send("trainingmode is required");
  
    next()
}