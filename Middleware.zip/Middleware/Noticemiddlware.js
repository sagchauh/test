export const addnoticemiddlware = (req, res, next) => {

    const { title, date } = req.body

    if (!title) return res.send("title is required");
    if (!date) return res.send("date is required");

    next()
}