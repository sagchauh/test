export const coursedatamiddlware = (req, res, next) => {
    const { course } = req.body;
    if (!course) return res.send("course is required");
    next()
}

export const dropdowncoursemiddlware = (req, res, next) => {
    const {course} = req.body;
    if (!course) return res.send("course is required");
    next()
}
