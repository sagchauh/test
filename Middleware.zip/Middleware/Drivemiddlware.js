export const uploaddrivelinkmiddlware = (req, res, next) => {

    const {githublink, drivelink, _id} = req.body

    if (!drivelink) return res.send("drivelink is required");
    if (!githublink) return res.send("githublink is required");
    if (!_id) return res.send("_id is required");

    next()
}