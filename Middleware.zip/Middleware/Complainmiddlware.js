export const addcomplainmiddlware = (req, res, next) => {

    const { complain, date, _id } = req.body;

    if (!complain) return res.send("complain is required")
    if (!date) return res.send("date is required")
    if (!_id) return res.send("_id is required")
    next()
}
