export const batchdatamiddlware = (req, res, next) => {

    const { batch, course, maxStudents } = req.body;
    if (!batch) return res.send("batch is required");
    if (!course) return res.send("course is required")
    if (!maxStudents) return res.send("maxStudents is required")
    next()
}

export const dropdownbatchmiddlware = (req, res, next) => {
    const { date } = req.body;
    if (!date) return res.send("date is required")
    next()
}