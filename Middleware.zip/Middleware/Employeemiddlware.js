import validator from "validator";
import Employee from "../Modal/EmployeeSchema.js";

export const employeeregistermiddlware = async (req, res, next) => {
    const { name, number, email, password } = req.body;
    console.log(req.body, "req.body")

    if (!name) return res.send("name is required");
    if (!number) return res.send("number is required");
    if (!email) return res.send("email is required");
    if (!password) return res.send("password is required");

    if (!validator.isEmail(email)) {
        return res.json({ status: 201, Message: "invalid email format" })
    }

    const isEmailExist = await Employee.findOne({ email });
    if (isEmailExist) {
        return res.json({ status: 202, Message: "Email already exists" })
    }

    next()
}

export const employeeloginmiddlware = (req, res, next) => {

    const { email, password } = req.body;

    if (!email) return res.send("enail is required");
    if (!password) return res.send("password is required");

    next()
}

export const updateemployeemiddlware = (req, res, next) => {

    const { _id } = req.body;

    if (!_id) return res.send("id is required")

    next()
}

export const deleteemployeemiddlware = (req, res, next) => {

    const { _id } = req.body;

    if (!_id) return res.send("id is required");

    next()
}

export const showsingleemployeemiddlware = (req, res, next) => {

    const { _id } = req.body;

    if (!_id) return res.send("id is required");

    next()
}

export const intimemiddlware = (req, res, next) => {

    const { _id, date, day, time } = req.body;

    if (!_id) return res.send("_id is required");
    if (!date) return res.send("date is required");
    if (!day) return res.send("day is required");
    if (!time) return res.send("time is required")

    next()
}

export const outtimemiddlware = (req, res, next) => {

    const { _id, date, day, time } = req.body;

    if (!_id) return res.send("_id is required");
    if (!date) return res.send("date is required");
    if (!day) return res.send("day is required");
    if (!time) return res.send("time is required")

    next()
}

export const editintimemiddlware = (req, res, next) => {

    const { _id, date, day, time } = req.body;

    if (!_id) return res.send("_id is required");
    if (!date) return res.send("date is required");
    if (!day) return res.send("day is required");
    if (!time) return res.send("time is required")

    next()
}

export const editouttimemiddlware = (req, res, next) => {

    const { _id, date, day, time } = req.body;

    if (!_id) return res.send("_id is required");
    if (!date) return res.send("date is required");
    if (!day) return res.send("day is required");
    if (!time) return res.send("time is required")

    next()
}