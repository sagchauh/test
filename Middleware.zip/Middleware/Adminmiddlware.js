import validator from "validator";
import Admin from "../Modal/AdminSchema.js";

export const adminregistermiddlware = async (req, res, next) => {

    const { name, email, password, number } = req.body;

    if (!name) return res.send("name is required")
    if (!email) return res.send("email is required")
    if (!number) return res.send("number is required");
    if (!password) return res.send("password is required");

    if (!validator.isEmail(email)) {
        return res.status(404).json({ error: "Invalid email format" });
    }

    const isEmailExist = await Admin.findOne({ email });
    if (isEmailExist) {
        return res.json({ status: 401, message: "Email already exists" })
    }

    if (!validator.isLength(number, { min: 10, max: 10 })) {
        return res.json({ status: 402, message: "Phone number must be 10 digits" })
    }

    if (!validator.isNumeric(number)) {
        return res.json({ status: 403, message: "Phone number must be numeric" })
    }

    next()
}


export const adminloginmiddlware = (req, res, next) => {

    const { email, password } = req.body;

    if (!email) return res.send("email is required");
    if (!password) return res.send("password is required");

    next()
}

export const verifyotpmiddlware = (req, res, next) => {

    const { _id, otp } = req.body;
    if (!_id) return res.send("_id is required")
    if (!otp) return res.send("otp is required")

    next()
}

export const forgetpasswordmiddlware = (req, res, next) => {

    const { email } = req.body
    if (!email) return res.send("email is required");

    next()
}

export const forgetpassverifyotpmiddlware = (req, res, next) => {

    const { _id, otp } = req.body

    if (!_id) return res.send("_id is required")
    if (!otp) return res.send("otp is required")
    next()
}

export const resetpasswordmiddlware = (req, res, next) => {

    const { _id, createnewpassword } = req.body;

    if (!_id) return res.send("_id is required")
    if (!createnewpassword) return res.send("createnewpassword is required")
    next()
}

export const showsingleadmindatamiddlware = (req, res, next) => {

    const { _id } = req.body

    if (!_id) return res.send("_id is required")
    next()
}


export const updateadmindatamiddlware = (req, res, next) => {
    const { _id, name, email } = req.body;
    console.log(_id, "_id");

    if (!_id) return res.send("_id is required")
    if (!name) return res.send("name is required")
    if (!email) return res.send("email is required")
    next()
}

export const deleteadminmiddlware = (req, res, next) => {
    const { _id } = req.body

    if (!_id) return res.send("_id is required")
    next()
}