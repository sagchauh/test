// export const subjectentermiddlware = (req, res, next) => {

//     const { subjectname } = req.body

//     if (!subjectname) return res.send("subjectname is required");
//     next()
// }