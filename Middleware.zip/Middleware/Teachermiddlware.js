import validator from "validator";
import Teacher from "../Modal/TeacherSchema.js";

export const teacherregistermiddlware = async (req, res, next) => {

    const { name, email, password, course } = req.body;

    if (!name) return res.send("name is required")
    if (!email) return res.send("email is required")
    if (!password) return res.send("password is required");
    if (!course) return res.send("course is required");

    if (!validator.isEmail(email)) {
        return res.status(401).json({ error: "Invalid email format" });
    }

    const isEmailExist = await Teacher.findOne({ email });
    if (isEmailExist) {
        return res.status(402).json({ error: "Email already exists" });
    }

    next()
}

export const teacherloginmiddlware = (req, res, next) => {

    const { email, password } = req.body;

    if (!email) return res.send("email is required")
    if (!password) return res.send("password is required");

    next()
}

export const assignedteachermiddlware = (req, res, next) => {
    const { name, _id } = req.body

    if (!name) return res.send("name is required")
    if (!_id) return res.send("_id is required")

    next()
}

export const teacherstudentdatamiddlware = (req, res, next) => {

    const { _id  } = req.body;

    if (!_id ) return res.send("_id  is required")
    next()
}