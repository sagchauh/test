import Notice from "../Modal/NoticeSchema.js";

export const addnotice = async (req, res) => {
    try {
        const { title, date } = req.body;

        const newNotice = new Notice({
            title: title,
            date: date,
        })
        await newNotice.save()

        return res.json({ status: 200, message: "notice add successfully", notice: newNotice })

    } catch (error) {
        return res.json({ status: 400, message: "Invalid Login" })
    }
}

export const shownotice = async (req, res) => {

    try {
        const showallnotice = await Notice.find({});
        console.log(showallnotice);
        res.send(showallnotice)
    } catch (error) {
        return res.json({ status: 400, message: "Invalid Login" })
    }

}