import Drive from "../Modal/DriveSchema.js";
import Student from "../Modal/StudentSchema.js";

export const uploaddrivelink = async (req, res) => {
    try {

        const { drivelink, _id, githublink, createsubject, date } = req.body;
        console.log(req.body, "rebody")

        const isdrivelink = await Drive.findOne({ drivelink });
        console.log(isdrivelink, "isdrivelink");

        if (isdrivelink) {
            return res.json({ status: 404, message: "drivelink is already present" });
        }

        const isgithublink = await Drive.findOne({ githublink });
        console.log(isgithublink, "isgithublink");

        if (isgithublink) {
            return res.json({ status: 405, message: "githublink is already present" });
        }

        const existingLinks = await Drive.findOne({ createsubject });
        console.log(existingLinks, "existingLinks");

        if (existingLinks) {
            return res.json({ status: 406, message: "Links for this subject already exist" });
        }

        const newlink = new Drive({
            drivelink: drivelink,
            githublink: githublink,
            createsubject: createsubject,
            date: date
        });
        console.log(newlink, "newlink")
        await newlink.save();

        const findstudent = await Student.findById(_id);
        console.log(findstudent, "findstudent");

        if (!findstudent) {
            return res.json({ status: 401, message: "student not found" });
        }

        findstudent.uploadlink.push(newlink._id);
        console.log(findstudent, "savestudent");

        const finaldata = await findstudent.save();
        console.log(finaldata, "finaldata")

        return res.json({ status: 200, message: "link uploaded successfully", finaldata: finaldata })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}



