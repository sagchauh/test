import Admin from "../Modal/AdminSchema.js";
import bcrypt from "bcrypt"
import jwt from 'jsonwebtoken';
import otpGenerator from "otp-generator"
import sendOtpSms from "../sendotpsms.js";
import nodemailer from "nodemailer"

const generateotp = () => {
    return otpGenerator.generate(6, { upperCase: false, specialChars: false, alphabets: false, digits: true });
};

export const adminregister = async (req, res) => {
    try {
        const { name, email, password, number, image } = req.body;

        const formattedNumber = `+91 ${number}`;

        const imagePath = req.file.path;

        const haspassword = await bcrypt.hash(password, 10);

        const newAdmin = new Admin({
            name: name,
            email: email,
            password: haspassword,
            number: formattedNumber,
            image: imagePath,
        })
        console.log(newAdmin, "-check")
        await newAdmin.save()

        return res.json({ status: 200, message: "Admin Registration Successfully", Data: newAdmin })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

const transporter = nodemailer.createTransport({
    service: "gmail",
    host: 'smtp.gmail.com',
    port: 587,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

export const adminlogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        const adminData = await Admin.findOne({ email });

        if (!adminData) {
            return res.json({ status: 201, message: "email is already present" })
        }

        const passwordcorrect = await bcrypt.compare(password, adminData.password);
        console.log(passwordcorrect, "passwordcorrect");

        if (!passwordcorrect) {
            return res.json({ status: 401, message: "password is incorrect" });
        }

        const otp = generateotp();

        const mailoption = {
            from: `"Maddison Foo Koch "<${process.env.EMAIL_USER}>`,
            to: adminData.email,
            subject: "Your OTP Code",
            text: `Your OTP code is ${otp}`,
            html: `<p>Your OTP code is <strong>${otp}</strong></p>`
        };

        transporter.sendMail(mailoption, async (error, info) => {
            if (error) {
                console.error('Error sending email:', error);
                return res.status(500).json({ message: "Error sending email" });
            }

            await sendOtpSms(adminData.number, otp);
            adminData.otp = otp;
            adminData.emailotp = otp;
            adminData.isverified = true;
            await adminData.save();

            // setTimeout(async () => {
            //     adminData.otp = null;
            //     adminData.emailotp = null;
            //     // adminData.timestamp = null;
            //     adminData.isverified = false;
            //     await adminData.save();
            // }, 30000);

            return res.json({ status: 200, message: "all details match", adminData })
        })

        // const studentjwt = jwt.sign({ _id: adminData._id, role: adminData.role, name: adminData.name, email: adminData.email }, process.env.JWT_SECRET);
        // console.log(studentjwt, "studentjwt");

        // const studentwithoutpassword = { _id: adminData._id, role: adminData.role, name: adminData.name, image: adminData.image };
        // console.log(studentwithoutpassword, "studentwithoutpassword");

        // return res.json({ status: 200, message: "Login Succesfully", logindata: studentjwt, withoutpass: studentwithoutpassword })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const verifyotp = async (req, res) => {
    try {
        const { _id, otp, emailotp } = req.body;
        console.log(req.body, "req.body")

        const adminData = await Admin.findById(_id);
        console.log(adminData, "adminData");

    //    if (!adminData) {
    //         return res.status(401).json({ message: "Admin not found" });
    //     }

    //     // Validate OTP
    //     if (adminData.otp !== otp || adminData.emailotp !== emailotp) {
    //         return res.status(402).json({ message: "Invalid OTP" });
    //     }

        if (!adminData) {
            return res.json({ status: 401, message: "findadmin not found" })
        }

        if (adminData.otp !== otp) {
            return res.json({ status: 402, message: "Invalid OTP" });
        }

        adminData.isverified = true;
        adminData.otp = null;
        adminData.emailotp = null;
        await adminData.save();

        const studentjwt = jwt.sign({ _id: adminData._id, role: adminData.role, name: adminData.name, email: adminData.email }, process.env.JWT_SECRET);
        console.log(studentjwt, "studentjwt");

        const studentwithoutpassword = { _id: adminData._id, role: adminData.role, name: adminData.name, image: adminData.image };
        console.log(studentwithoutpassword, "studentwithoutpassword");

        return res.json({ status: 200, message: "otp validate", logindata: studentjwt, withoutpass: studentwithoutpassword })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const forgetpassword = async (req, res) => {

    try {
        const { email } = req.body

        const findemail = await Admin.findOne({ email });
        console.log(findemail, "findemail");

        if (!findemail) {
            return res.json({ status: 401, message: "email not found" })
        }

        const otp = generateotp();

        const mailoption = {
            from: `"Maddison Foo Koch "<${process.env.EMAIL_USER}>`,
            to: findemail.email,
            subject: "Your OTP Code",
            text: `Your OTP code is ${otp}`,
            html: `<p>Your OTP code is <strong>${otp}</strong></p>`
        };

        transporter.sendMail(mailoption, async (error, info) => {
            if (error) {
                console.error('Error sending email:', error);
                return res.status(500).json({ message: "Error sending email" });
            }

            await sendOtpSms(findemail.number, otp);
            findemail.otp = otp;
            findemail.emailotp = otp;
            findemail.isverified = true;
            await findemail.save();

            setTimeout(async () => {
                findemail.otp = null;
                findemail.emailotp = null;
                // adminData.timestamp = null;
                findemail.isverified = false;
                await findemail.save();
            }, 30000);

            return res.json({ status: 200, message: "otp is sent in your registered moible number", findemail })
        })


        // await sendOtpSms(findemail.number, otp);
        // findemail.otp = otp;
        // await findemail.save();

        // setTimeout(async () => {
        //     findemail.otp = null;
        //     // findadmin.timestamp = null;
        //     findemail.isverified = false;
        //     await findemail.save();
        // }, 30000);

        // return res.json({ status: 200, message: "otp is sent in your registered moible number", findemail })


    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }

}

export const forgetpassverifyotp = async (req, res) => {

    try {
        const { _id, otp, emailotp } = req.body

        const adminData = await Admin.findById({ _id });
        console.log(adminData, "adminData");

        if (!adminData) {
            return res.json({ status: 401, message: "admin is not found" });
        }

        if (adminData.otp !== otp || adminData.emailotp !== emailotp) {
            return res.json({ status: 402, message: "Invalid OTP" });
        }

        adminData.isverified = true;
        adminData.otp = null;
        adminData.emailotp = null;
        await adminData.save();

        return res.json({ status: 200, message: "otp validate" })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const resetpassword = async (req, res) => {
    try {
        const { _id, createnewpassword } = req.body;

        const haspassword = await bcrypt.hash(createnewpassword, 10);

        const updatepassword = await Admin.findByIdAndUpdate(_id, {
            password: haspassword
        })

        console.log(updatepassword, "updatepassword")

        return res.json({ status: 200, message: "password reset successfully", updatepassword });

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const adminlist = async (req, res) => {
    try {
        const alladmindata = await Admin.find({});
        console.log(alladmindata, "alladmindata");

        return res.send(alladmindata)
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }

}

export const showsingleadmindata = async (req, res) => {
    try {
        const { _id } = req.body

        const findsingleadmin = await Admin.findById(_id);
        console.log(findsingleadmin, "findsingleadmin");

        return res.send(findsingleadmin)
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const updateadmindata = async (req, res) => {
    try {
        const { _id, name, email } = req.body;

        const updateadmin = await Admin.findByIdAndUpdate(_id, {
            name: name,
            email: email,
        })

        const imagePath = req.file ? req.file.path : null;

        if (req.file) {
            updateadmin.image = imagePath;
        }

        await updateadmin.save();

        return res.json({ status: 200, message: "admin data update successfully" })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const deleteadmin = async (req, res) => {
    try {
        const { _id } = req.body;

        const deleteadmin = await Admin.findByIdAndDelete(_id);
        console.log(deleteadmin, "deleteadmin");

        if (!deleteadmin) {
            return res.json({ status: 401, message: "admin not found" });
        }

        return res.json({ status: 200, message: "Admin delete successfully" })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}