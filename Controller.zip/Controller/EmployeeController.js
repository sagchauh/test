import bcrypt from "bcrypt"
import Employee from "../Modal/EmployeeSchema.js";
import jwt from 'jsonwebtoken';


export const employeeregister = async (req, res) => {
    try {
        const { name, number, email, password, image } = req.body;
        console.log(req.body, "req.body")

        const hashpassword = await bcrypt.hash(password, 10);
        console.log(hashpassword, "hashpassword")

        const formattednumber = `+91 ${number}`
        console.log(formattednumber, "formattednumber")

        const imagePath = req.file.path;
        console.log(imagePath, "imagePath");

        const newemployee = new Employee({
            name: name,
            number: formattednumber,
            email: email,
            password: hashpassword,
            image: imagePath,
        })

        await newemployee.save();

        return res.json({ status: 200, message: "Employee register successfully", newemployee })
    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })

    }
}

export const employeelogin = async (req, res) => {

    try {
        const { email, password } = req.body;

        const studentdata = await Employee.findOne({ email });
        console.log(studentdata, "studentdata");

        if (!studentdata) {
            return req.json({ status: 401, message: "email is already present" })
        }

        const decodepassword = await bcrypt.compare(password, studentdata.password);
        console.log(decodepassword, "decodepassword");

        if (!decodepassword) {
            return res.json({ status: 402, message: "password is incorrect" })
        }

        const studentjwt = jwt.sign({ _id: studentdata._id, role: studentdata.role, name: studentdata.name, email: studentdata.email }, process.env.JWT_SECRET);
        console.log(studentjwt, "studentjwt");

        const studentwithoutpassword = { _id: studentdata._id, role: studentdata.role, name: studentdata.name, image: studentdata.image, };
        console.log(studentwithoutpassword, "studentwithoutpassword");

        return res.json({ status: 200, message: "login successfully", logindata: studentjwt, withoutpass: studentwithoutpassword })
    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }
}

export const showsingleemployee = async (req, res) => {

    try {

        const { _id } = req.body;

        const showemployee = await Employee.findById(_id);
        console.log(showemployee, "showemployee");

        if (!showemployee) {
            return res.json({ status: 401, message: "employee not found" })
        }

        return res.send(showemployee)

    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }

}

export const updateemployee = async (req, res) => {

    try {
        const { _id, name, email, number } = req.body;

        const findemployee = await Employee.findById({ _id });
        console.log(findemployee, "findemployee");

        if (!findemployee) {
            return req.json({ status: 401, message: "employee not found" })
        }

        const updatedata = await Employee.findByIdAndUpdate(_id, {
            name: name,
            email: email,
            number, number
        })
        console.log(updatedata, "updatedata");

        await updatedata.save();

        return res.json({ status: 200, message: "employee data updated successfully", updatedata })
    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }
}

export const deleteemployee = async (req, res) => {
    try {

        const { _id } = req.body;

        const deleteemployee = await Employee.findByIdAndDelete(_id);
        console.log(deleteemployee, "deleteemployee");

        if (!deleteemployee) {
            return res.json({ statu: 401, message: "employee not found" })
        }

        return res.json({ status: 200, message: "employee delete successfully" })

    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }
}

export const showemployeelist = async (req, res) => {

    try {

        const showalldetail = await Employee.find({});
        console.log(showalldetail, "showalldetail");

        return res.send(showalldetail)

    }
    catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }

}

export const intime = async (req, res) => {
    try {
        const { _id, date, day, time } = req.body;
        console.log(req.body, "req.body");

        const findstudent = await Employee.findById({ _id });
        console.log(findstudent, "findstudent");

        if (!findstudent) {
            return res.json({ status: 401, message: "Employee not found" });
        }

        const existingintime = findstudent.intime.find(att => new Date(att.date).toDateString() === new Date(date).toDateString());
        console.log(existingintime, "existingintime");

        if (existingintime) {
            return res.json({ status: 402, message: "In time already recorded for this employee on this date" });
        }

        findstudent.intime.push({ date, day, time });
        console.log(findstudent, "findstudent updated");

        const updateintime = await findstudent.save();
        console.log(updateintime, "updateintime");

        return res.json({ status: 200, message: "Intime updated successfully" });

    } catch (error) {
        console.error("Error updating intime:", error);
        return res.json({ status: 400, message: "Invalid error", error: error.message });
    }
}

export const outtime = async (req, res) => {
    try {
        const { _id, date, day, time } = req.body;

        const findstudent = await Employee.findById({ _id });
        console.log(findstudent, "findstudent");

        if (!findstudent) {
            return res.json({ status: 401, message: "Employee not found" });
        }

        const existingouttime = findstudent.outtime.find(att => new Date(att.date).toDateString() === new Date(date).toDateString());
        console.log(existingouttime, "existingouttime");

        if (existingouttime) {
            return res.json({ status: 402, message: "Out time already recorded for this employee on this date" });
        }

        findstudent.outtime.push({ date, day, time });
        console.log(findstudent, "findstudent updated");

        const updateouttime = await findstudent.save();
        console.log(updateouttime, "updateouttime");

        return res.json({ status: 200, message: "Outtime updated successfully" });

    } catch (error) {
        console.error("Error updating outtime:", error);
        return res.json({ status: 400, message: "Invalid error", error: error.message });
    }
}


export const editintime = async (req, res) => {
    try {

        const { _id, date, day, time } = req.body;

        const findemployee = await Employee.findById(_id);
        console.log(findemployee, "findemployee");

        if (!findemployee) {
            return res.json({ status: 401, message: "employee not found" })
        }

        const updateintime = findemployee.intime;
        console.log(updateintime, "updateintime");

        if (!updateintime) {
            return res.json({ status: 402, message: "employee attendance not found" })
        }

        let intime = false;

        for (let i = 0; i < updateintime.length; i++) {
            if (new Date(updateintime[i].date).toDateString() === new Date(date).toDateString()) {
                updateintime[i].day = day;
                updateintime[i].time = time;
                intime = true;
                break;
            }
        }

        if (!intime) {
            return res.json({ status: 403, message: "Employee attendance not found for the specified date" });
        }

        console.log(findemployee, "findemployee");
        await findemployee.save();

        return res.json({ status: 200, message: "intime edit successfully" })

    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }
}

export const editouttime = async (req, res) => {

    try {

        const { _id, date, day, time } = req.body;

        const findemployee = await Employee.findById(_id);
        console.log(findemployee, "findemployee");

        if (!findemployee) {
            return res.json({ status: 401, message: "employee not found" })
        }

        const updateouttime = findemployee.outtime;
        console.log(updateouttime, "updateouttime");

        let outtime = false

        for (let i = 0; i < updateouttime.length; i++) {
            if (new Date(updateouttime[i].date).toDateString() === new Date(date).toDateString()) {
                updateouttime[i].day = day;
                updateouttime[i].time = time;
                outtime = true;
                break;
            }
        }

        if (!outtime) {
            return res.json({ status: 403, message: "Employee attendance not found for the specified date" });
        };

        console.log(findemployee, "findemployee");
        await findemployee.save();

        return res.json({ status: 200, message: "outtime edit successfully" })

    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message })
    }

}