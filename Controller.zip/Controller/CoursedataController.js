
import Course from "../Modal/CourseSchema.js";
import Trainingmode from "../Modal/TraningmodeSchema.js"

export const coursedata = async (req, res) => {
    try {
        const { course, trainingmodes } = req.body;

        const hasOnline = trainingmodes.includes("online");
        const hasOffline = trainingmodes.includes("offline");

        if (!hasOnline || !hasOffline) {
            return res.json({ status: 202, message: "Please select both online and offline training modes" });
        }

        const existingCourse = await Course.findOne({ course });

        if (existingCourse) {
            return res.json({ status: 203, message: "Course already exists", courseInfo: existingCourse });
        } else {
            const trainingModeObjects = await Trainingmode.find({ trainingmode: { $in: trainingmodes } });

            if (!trainingModeObjects || trainingModeObjects.length !== trainingmodes.length) {
                return res.json({ status: 204, message: "One or more training modes not found" });
            }

            const newCourse = new Course({
                course,
                trainingmode: trainingModeObjects.map(trainingMode => trainingMode._id),
            });

            await newCourse.save();
            return res.json({ status: 200, message: "Course created successfully", courseInfo: newCourse });
        }
    } catch (error) {
        return res.json({ status: 400, message: "Invalid request", error: error.message });
    }
};



export const getallcourse = async (req, res) => {
    try {
        const showallcourses = await Course.find({}).populate("trainingmode");
        console.log(showallcourses, "-check");
        return res.send(showallcourses)
    } catch (error) {
        return res.json({ status: 400, message: "courses not found" })
    }
}

export const dropdowncourse = async (req, res) => {
    try {
        const { course } = req.body;

        const dropdowncourse = await Course.findOne({ course });

        if (dropdowncourse) {
            return res.json({ status: 200, message: "Course update successfully" })
        } else {
            return res.json({ status: 401, message: "course not found" })
        }
    } catch (error) {
        return res.json({ status: 400, message: "error" })
    }
}

export const getallcoursedata = async (req, res) => {
    try {
        const courseinfo = await Course.find({}).populate('course');
        console.log(courseinfo, "courseinfo");
        res.json(courseinfo)

    } catch (error) {
        return res.json({ status: 400, message: "error" })
    }
}

