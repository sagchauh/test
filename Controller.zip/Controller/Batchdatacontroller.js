import Batch from "../Modal/BatchSchema.js";
import Course from "../Modal/CourseSchema.js";

export const batchdata = async (req, res) => {
    try {
        const { course, maxStudents, batch } = req.body;

        const batchExists = await Batch.findOne({ batch, 'course.course': course });
        console.log(batchExists, "batchExists");

        const coursedata = await Course.findOne({ course });
        console.log(coursedata, "coursedata");

        if (!coursedata) {
            return res.json({ status: 201, message: "Course not found" });
        }

        if (batchExists) {
            return res.json({ status: 202, message: "Batch already exists for the selected course", batchinfo: batchExists });
        } else {
            const newBatch = new Batch({
                batch,
                course: coursedata,
                maxStudents
            });
            await newBatch.save();
            return res.json({ status: 200, message: "Batch created successfully", batchdata: newBatch });
        }
    } catch (error) {
        return res.status(400).json({ status: 400, message: "Invalid error", error: error.message });
    }
}

export const getallbatch = async (req, res) => {
    try {
        const showallbatch = await Batch.find({}).populate('course');
        console.log(showallbatch, "-check");
        return res.send(showallbatch)

    } catch (error) {
        return res.json({ status: 400, message: "batch not found" })
    }
}

export const dropdownbatch = async (req, res) => {
    try {

        const { date } = req.body;

        const queryDate = new Date(date);

        const formattedDate = new Date(Date.UTC(queryDate.getFullYear(), queryDate.getMonth(), queryDate.getDate()));

        const dropdownbatch = await Batch.findOne({ date: formattedDate }).populate("course");

        if (dropdownbatch) {
            return res.json({ status: 200, message: "batch update successfully", dropdownbatchdata: dropdownbatch })
        } else {
            return res.json({ status: 401, message: "batch not found" })
        }
    } catch (error) {
        return res.json({ status: 400, message: "error" })
    }

}