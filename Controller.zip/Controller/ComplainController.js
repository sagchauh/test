import Complain from "../Modal/ComplainSchema.js";
import Student from "../Modal/StudentSchema.js";

export const addcomplain = async (req, res) => {

    try {
        const { complain, date, _id } = req.body;

        const student = await Student.findById(_id);
        if (!student) {
            return res.json({ status: 401, message: "Student not found" })
        }

        const newComplain = new Complain({
            complain: complain,
            date: date,
            studentId: student,
        });

        await newComplain.save();
        return res.json({ status: 200, message: "Complaint registered successfully. We will take action.", complain: newComplain })

    } catch (error) {
        return res.json({ status: 400, message: "Invalid Login" })
    }

}

// export const showcomplain = async (req, res) => {
//     try {

//         const showcomplain = await Complain.find({}).populate('studentId')
//         console.log(showcomplain, "showcomplain");
//         res.send(showcomplain)

//     } catch (error) {
//         return res.json({ status: 400, message: "Invalid Login" })
//     }
// }

export const showcomplain = async (req, res) => {
    try {
        const complaints = await Complain.find({}).populate({ path: 'studentId', 
        populate: [{ path: 'batch', model: 'Batch', select: 'batch' }, { path: 'course', model: 'Course', select: 'course' }, { path: 'assignedteacher', model: 'Teacher', select: 'name' }] });

        console.log(complaints, "showcomplain");

        res.send(complaints);
    } catch (error) {
        return res.json({ status: 400, message: "Invalid Login" })
    }
};

export const deletecomplain = async (req, res) => {
    try {
        const { _id } = req.body;

        const deletedata = await Complain.findByIdAndDelete(_id);
        console.log(deletedata, "deletedata");

        return res.json({status:200, message:"complain delete successfully"})

    } catch (error) {
        return res.json({ status: 400, message: "Invalid Login" })
    }

}



