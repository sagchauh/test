import Student from "../Modal/StudentSchema.js";
import Batch from "../Modal/BatchSchema.js";
import bcrypt from "bcrypt";
import Course from "../Modal/CourseSchema.js";
import Subject from "../Modal/SubSchema.js";
import jwt from 'jsonwebtoken';
import Teacher from "../Modal/TeacherSchema.js";
import Createsubject from "../Modal/CreatesubjectSchema.js";
import Drive from "../Modal/DriveSchema.js";
import Trainingmode from "../Modal/TraningmodeSchema.js";
import { trainingmode } from "./TrainingmodeController.js";
import twilio from 'twilio';
import nodemailer from "nodemailer"


export const studentregister = async (req, res) => {
    try {
        const { name, email, password, number, fees, course, batch, trainingmode, trainingmodule, assignedteacher, date } = req.body;
        console.log(req.body, "req.body");

        const hashedPassword = await bcrypt.hash(password, 10);

        const formattedNumber = `+91 ${number}`;

        const imagePath = req.file.path;
        console.log(req.file, "req.file");

        const courseInstance = await Course.findById(course);
        console.log(courseInstance, "courseInstance");

        if (!courseInstance) {
            return res.json({ status: 402, message: "Course not found" });
        }

        const batchInstance = await Batch.findOne({ batch, course: courseInstance._id });
        console.log(batchInstance, "batchInstance");

        if (!batchInstance) {
            return res.json({ status: 401, message: "Batch not found" });
        }

        const teacherInstance = await Teacher.findOne({ name: assignedteacher });
        console.log(teacherInstance, "teacherInstance");

        if (!teacherInstance) {
            return res.json({ status: 403, message: "Teacher not found" });
        }

        const trainingInstance = await Trainingmode.findOne({ trainingmode });
        console.log(trainingInstance, "trainingInstance");

        if (!trainingInstance) {
            return res.json({ status: 404, message: "Training mode not found" });
        }

        const batchDate = new Date(date);

        // Check if a batch with the same course, batch, and date already exists
        let existingBatch = await Batch.findOne({ course: courseInstance._id, batch: batchInstance.batch, date: batchDate });
        console.log(existingBatch, "existingBatch");

        if (!existingBatch) {
            // Create a new batch for the given date if it does not exist
            existingBatch = new Batch({
                batch: batchInstance.batch,
                date: batchDate,
                maxStudents: batchInstance.maxStudents,
                offlineEnrollment: 0,
                onlineEnrollment: 0,
                course: courseInstance._id
            });
            console.log(existingBatch, "newBatch");
            await existingBatch.save();
        }

        // Update batch enrollment count based on training mode
        if (trainingInstance.trainingmode === 'online') {
            if (existingBatch.onlineEnrollment >= existingBatch.maxStudents) {
                return res.json({ status: 405, message: "Batch is full for online enrollment" });
            }
            existingBatch.onlineEnrollment++;
        } else if (trainingInstance.trainingmode === 'offline') {
            if (existingBatch.offlineEnrollment >= existingBatch.maxStudents) {
                return res.json({ status: 406, message: "Batch is full for offline enrollment" });
            }
            existingBatch.offlineEnrollment++;
        }

        await existingBatch.save();

        const newStudent = new Student({
            name,
            email,
            password: hashedPassword,
            testresult: undefined,
            batch: existingBatch._id,
            course: courseInstance._id,
            number: formattedNumber,
            fees,
            trainingmode: trainingInstance,
            trainingmodule,
            image: imagePath,
            assignedteacher: teacherInstance,
            date,
        });

        await newStudent.save();

        return res.json({ status: 200, message: "Student Registration Successful", data: newStudent });
    } catch (error) {
        return res.status(400).json({ status: 400, message: "Invalid error", error: error.message });
    }
};


export const deletestudent = async (req, res) => {
    try {
        const { _id } = req.body;

        const student = await Student.findById(_id).populate('batch').populate('trainingmode');

        if (!student) {
            return res.json({ status: 401, message: "Student not found" })
        }

        const currentbatch = await Batch.findById(student.batch);
        console.log(currentbatch, "currentbatch");

        const currenttraininmode = await Trainingmode.findOne({ trainingmode });
        console.log(currenttraininmode, "currenttraininmode")

        if(currentbatch){
            const findtrainingmode = await Trainingmode.findById(student.trainingmode);
            console.log(findtrainingmode, "findtrainingmode");
            if(findtrainingmode.trainingmode === "offline"){
                currentbatch.offlineEnrollment = Math.max(0, currentbatch.offlineEnrollment -1)
            }else{
                currentbatch.onlineEnrollment = Math.max(0, currentbatch.onlineEnrollment -1);
            }
            await currentbatch.save();
        }


        await Student.deleteOne({ _id: student._id });

        return res.json({ status: 200, message: "Student deleted successfully" })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const getrespectiveteachernames = async (req, res) => {
    try {
        const { date, courseId } = req.body;

        // Convert the date string to a Date object
        const selectedDate = new Date(date);
        const startOfDay = new Date(Date.UTC(selectedDate.getUTCFullYear(), selectedDate.getUTCMonth(), selectedDate.getUTCDate(), 0, 0, 0));
        const endOfDay = new Date(Date.UTC(selectedDate.getUTCFullYear(), selectedDate.getUTCMonth(), selectedDate.getUTCDate(), 23, 59, 59));

        // Find the course by its ID and populate its teachers
        const course = await Course.findById(courseId).populate('teachers');
        if (!course) {
            return res.status(404).json({ message: "Course not found" });
        }

        // Query to find batches within the selected date range
        const batchesWithCourseAndDate = await Batch.find({
            course: courseId,
            date: { $gte: startOfDay, $lte: endOfDay }
        }).populate({
            path: 'course',
            populate: [
                { path: 'teachers' },
                { path: 'trainingmode' }
            ]
        });

        // Fetch all global batches
        const allGlobalBatches = await Batch.find({
            course: courseId,
            date: { $exists: false }
        }).populate('course');

        // Combine the matched batches and the global batches, ensuring no duplicate batch is added
        const responseBatches = [...batchesWithCourseAndDate];

        // Find which global batch is already included
        const includedBatches = new Set(batchesWithCourseAndDate.map(batch => batch.batch));

        // Add global batches that are not included in the matched batches
        allGlobalBatches.forEach(globalBatch => {
            if (!includedBatches.has(globalBatch.batch)) {
                responseBatches.push(globalBatch);
            }
        });

        return res.json(responseBatches);
    } catch (error) {
        return res.status(400).json({ message: "Invalid error", error: error.message });
    }
};




export const fetchteachname = async (req, res) => {
    try {

        const { courseId } = req.body;

        const findcourse = await Course.findById(courseId).populate('teachers');
        console.log(findcourse, "findcourse");

        if (!findcourse) {
            return res.json({ status: 401, message: "course not found" })
        }

        return res.send(findcourse)

    } catch (error) {
        return res.status(400).json({ message: "Invalid error", error: error.message });
    }
}




export const studentlogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        const studentdata = await Student.findOne({ email })

        if (!studentdata) {
            return res.json({ status: 401, message: "email is already present" })
        }

        const passwordcorrect = await bcrypt.compare(password, studentdata.password);
        console.log(passwordcorrect, "passwordcorrect")

        if (!passwordcorrect) {
            return res.json({ status: 402, message: "password is incorrect" })
        }

        // const findcourse = await Course.findById(studentdata.course);
        // console.log(findcourse, "findcourse");

        // if (!findcourse) {
        //     return res.json({ status: 402, message: "Course not found" })
        // }

        const termsaccepted = studentdata.termscondition
        console.log(termsaccepted, "termsaccepted");

        const studentjwt = jwt.sign({ _id: studentdata._id, batch: studentdata.batch, course: studentdata.course, role: studentdata.role, name: studentdata.name, email: studentdata.email }, process.env.JWT_SECRET);
        console.log(studentjwt, "studentjwt");

        const studentwithoutpassword = { _id: studentdata._id, role: studentdata.role, name: studentdata.name, image: studentdata.image, };  //course: findcourse
        console.log(studentwithoutpassword, "studentwithoutpassword");

        return res.json({ status: 200, message: "Login Succesfully", termsaccepted, logindata: studentjwt, withoutpass: studentwithoutpassword })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


// export const getcurrentstudent = async (req, res) => {
//     try {
//         const token = req.headers.authorization.split(" ")[1];

//         const decodestudentjwt = jwt.verify(token, process.env.JWT_SECRET);

//         const studentId = decodestudentjwt._id;

//         const verifystudent = await Student.findById(studentId).select('-password');

//         if (!verifystudent) {
//             return res.status(401).json({ message: "Student not found" });
//         }

//         return res.status(200).json({ verifystudent });
//     } catch (error) {
//         return res.status(400).json({ message: "Invalid error" });
//     }
// };



const transporter = nodemailer.createTransport({
    service: "gmail",
    host: 'smtp.gmail.com',
    port: 587,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

export const acceptpolicy = async (req, res) => {
    try {
        const { email } = req.body;

        const studentdata = await Student.findOneAndUpdate({ email }, { termscondition: true }, { new: true });
        console.log(studentdata, "studentdata");

        if (!studentdata) {
            return res.json({ status: 402, message: "Invalid email or password" });
        }

        const mailoption = {
            from: `"Maddison Foo Koch "<${process.env.EMAIL_USER}>`,
            to: studentdata.email,
            subject: "Policy Accepted",
            text: "You have successfully accepted the policy.",
            html: '<p>You have successfully accepted the policy.</p>'
        };

        transporter.sendMail(mailoption, (error, info) => {
            if (error) {
                console.error('Error sending email:', error);
                return res.json({ status: 401, message: "Error sending email" });
            }
            console.log('Email sent: %s', info.messageId);

            const studentjwt = jwt.sign(
                { _id: studentdata._id, batch: studentdata.batch, course: studentdata.course, role: studentdata.role, name: studentdata.name, email: studentdata.email },
                process.env.JWT_SECRET
            );
            console.log(studentjwt, "studentjwt");

            const studentwithoutpassword = { _id: studentdata._id, role: studentdata.role, name: studentdata.name, image: studentdata.image };
            console.log(studentwithoutpassword, "studentwithoutpassword");

            return res.json({ status: 200, message: "Terms accepted successfully", logindata: studentjwt, withoutpass: studentwithoutpassword });
        });

    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message });
    }
};


export const getcurrentstudent = async (req, res) => {
    try {

        const { studentjwt } = req.body;
        console.log(studentjwt, "studentjwt");

        const decodestudentjwt = jwt.verify(studentjwt, process.env.JWT_SECRET);
        console.log(decodestudentjwt, "decodestudentjwt");

        const studentId = decodestudentjwt._id;
        console.log(studentId, "studentId");

        const verifystudent = await Student.findById(studentId).select('-password');
        console.log(verifystudent, "verifystudent");

        if (!verifystudent) {
            return res.json({ status: 401, message: "student not found" })
        }

        return res.json({ status: 200, message: "student found successfully", verifystudent: verifystudent })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const singlestudentdata = async (req, res) => {
    try {
        const { _id } = req.body;

        const singlestudent = await Student.findById(_id).populate('batch').populate('course').populate('assignedteacher').populate('trainingmode');
        console.log(singlestudent, "singlestudent");

        return res.json(singlestudent)
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


// export const updatestudentdata = async (req, res) => {
//     try {
//         const { _id, name, email, number, fees, course, batch, trainingmode, trainingmodule, assignedteacher, date } = req.body;
//         console.log(req.body, "req.body");

//         const findstudent = await Student.findById(_id);
//         console.log(findstudent, "findstudent");

//         if (!findstudent) {
//             return res.json({ status: 401, message: "student not found" });
//         }

//         const currentbatch = await Batch.findById(findstudent.batch);
//         console.log(currentbatch, "currentbatch");

//         const coursename = await Course.findById(course);
//         console.log(coursename, "coursename");

//         const batchname = await Batch.findOne({ batch, course: course });
//         console.log(batchname, "batchname");

//         const teachername = await Teacher.findOne({ name: assignedteacher });
//         console.log(teachername, "teachername");

//         const trainingInstance = await Trainingmode.findOne({ trainingmode });
//         console.log(trainingInstance, "trainingInstance");

//         const updatestudent = await Student.findByIdAndUpdate(_id, {
//             name: name,
//             email: email,
//             batch: batchname._id, // Store the batch ID
//             course: coursename._id,
//             number: number,
//             fees: fees,
//             trainingmode: trainingInstance,
//             trainingmodule: trainingmodule,
//             assignedteacher: teachername._id, // Store the teacher ID
//             date: new Date(date),
//         }, { new: true });

//         if (!updatestudent) {
//             return res.json({ status: 401, message: "student not found" });
//         }

//         // Update the batch schema data
//         // Decrement the enrollment of the current batch
//         if (currentbatch) {
//             if (findstudent.trainingmode.toString() === "offline") {
//                 currentbatch.offlineEnrollment -= 1;
//             } else {
//                 currentbatch.onlineEnrollment -= 1;
//             }
//             await currentbatch.save();
//         }

//         // Increment the enrollment of the new batch
//         if (batchname) {
//             if (trainingInstance.trainingmode.toString() === "offline") {
//                 batchname.offlineEnrollment += 1;
//             } else {
//                 batchname.onlineEnrollment += 1;
//             }
//             await batchname.save();
//         }

//         return res.json({ status: 200, message: "Student updated successfully", updatestudent });

//     } catch (error) {
//         return res.json({ status: 400, message: "invalid error", error: error.message });
//     }
// };



export const updatestudentdata = async (req, res) => {
    try {
        const { _id, name, email, number, fees, course, batch, trainingmode, trainingmodule, assignedteacher, date } = req.body;
        console.log(req.body, "req.body");

        // Find the current student data
        const currentStudent = await Student.findById(_id);
        if (!currentStudent) {
            return res.json({ status: 401, message: "student not found" });
        }

        // Find current batch using the batch ID
        const currentBatch = await Batch.findById(currentStudent.batch);
        console.log(currentBatch, "currentBatch");

        // Find new course, batch, teacher and training mode
        const coursename = await Course.findById(course);
        console.log(coursename, "coursename");

        const batchname = await Batch.findOne({ batch, course, date });
        console.log(batchname, "batchname");

        const teachername = await Teacher.findOne({ name: assignedteacher });
        console.log(teachername, "teachername");

        const trainingInstance = await Trainingmode.findOne({ trainingmode });
        console.log(trainingInstance, "trainingInstance");

        // Update the student data
        const updatestudent = await Student.findByIdAndUpdate(_id, {
            name: name,
            email: email,
            batch: batchname._id,
            course: coursename._id,
            number: number,
            fees: fees,
            trainingmode: trainingInstance,
            trainingmodule: trainingmodule,
            assignedteacher: teachername._id,
            date: new Date(date),
        }, { new: true });

        if (!updatestudent) {
            return res.json({ status: 401, message: "student not found" });
        }

        // Update the batch schema data
        // Decrement the enrollment of the current batch
        if (currentBatch) {
            const currentTrainingMode = await Trainingmode.findById(currentStudent.trainingmode);
            console.log(currentTrainingMode, "currentTrainingMode")
            if (currentTrainingMode.trainingmode === "offline") {
                currentBatch.offlineEnrollment = Math.max(0, currentBatch.offlineEnrollment - 1);
            } else {
                currentBatch.onlineEnrollment = Math.max(0, currentBatch.onlineEnrollment - 1);
            }
            await currentBatch.save();
        }

        // Increment the enrollment of the new batch
        if (batchname) {
            if (trainingmode === "offline") {
                batchname.offlineEnrollment += 1;
            } else {
                batchname.onlineEnrollment += 1;
            }
            await batchname.save();
        }

        return res.json({ status: 200, message: "Student updated successfully", updatestudent });
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message });
    }
};

export const getallstudentdata = async (req, res) => {
    try {
        const getallstudent = await Student.find({}).populate('batch').populate('course').populate('assignedteacher');
        console.log(getallstudent, "getallstudent");
        return res.send(getallstudent);
    } catch (error) {
        return res.json({ status: 400, message: "invalid error" })
    }
};

export const showparticularstudentdata = async (req, res) => {
    try {
        const { _id } = req.body

        const showsinglestudent = await Student.findById(_id).populate('batch').populate('course').populate('createsubject')
            .populate({
                path: 'testresult.uploadmarks',
                model: 'Drive',
                populate: {
                    path: 'createsubject',
                    model: 'createsubject'
                }
            });
        console.log(showsinglestudent, "showsinglestudent heree");

        if (!showsinglestudent) {
            return res.json({ status: 401, message: "student marks not found" })
        }

        return res.json({ status: 200, message: "see marks", marks: showsinglestudent })

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const studentdata = async (req, res) => {

    try {
        const { _id } = req.body

        const studentinfo = await Student.find({ _id }).populate('batch').populate('course').populate('assignedteacher').populate([{
            path: 'createsubject',
            model: 'createsubject',
            select: 'createsubject'
        }]);
        console.log(studentinfo, "studentinfo");

        if (!studentinfo) {
            return res.json({ status: 401, message: "student not found" });
        }

        return res.send(studentinfo)
        return res.json({ status: 200, message: "get studentdata" })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const findupdatedata = async (req, res) => {
    try {
        const { _id } = req.body;

        const fetchdata = await Student.findById(_id).populate('uploadlink').populate({   /// .populate('testresult.uploadmarks')
            path: 'uploadlink',
            // options: { sort: { 'date': -1 }, limit: 1 },
            populate: {
                path: 'createsubject',
                model: 'createsubject',
            }
        });
        console.log(fetchdata, "fetchdata");

        return res.send(fetchdata)

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const updatemarks = async (req, res) => {
    try {
        const { drivedataId, markobtained, _id } = req.body;

        const findstudent = await Student.findById(_id);
        if (!findstudent) {
            return res.json({ status: 401, message: "Student not found" });
        }

        const finddrivedata = await Drive.findById(drivedataId);
        if (!finddrivedata) {
            return res.json({ status: 402, message: "Drive data not found" });
        }

        const existingMarksIndex = findstudent.testresult.findIndex(result => result.uploadmarks.toString() === drivedataId.toString());
        if (existingMarksIndex !== -1) {
            return res.json({ status: 403, message: "Marks already updated for this subject" });
        }

        const testresultdata = {
            markobtained,
            uploadmarks: finddrivedata._id
        };

        findstudent.testresult.push(testresultdata);
        const updatedata = await findstudent.save();

        return res.json({ status: 200, message: "Test result updated successfully", updatedmarks: updatedata });
    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message });
    }
};



export const editmarksdata = async (req, res) => {

    try {
        const { _id } = req.body

        const showeditmarks = await Student.findById(_id).populate('batch')
            .populate('course')
            .populate('createsubject')
            .populate({
                path: 'testresult',
                populate: {
                    path: 'uploadmarks',
                    model: 'Drive',
                    populate: {
                        path: 'createsubject',
                        model: 'createsubject'
                    }
                }
            });
        console.log(showeditmarks, "showeditmarks");

        return res.send(showeditmarks)
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }

}

export const editfinalmarks = async (req, res) => {
    try {
        const { _id, testResultId, markobtained } = req.body;

        // Find the student by ID
        const student = await Student.findById(_id);
        console.log(student, "student data");

        if (!student) {
            return res.json({ status: 401, message: "Student not found" });
        }

        // Find the specific test result within the student's test results
        const testResultIndex = student.testresult.findIndex(result => result._id.toString() === testResultId.toString());
        console.log(testResultIndex, "test result index");

        if (testResultIndex === -1) {
            return res.json({ status: 402, message: "Test result not found" });
        }

        // Update the marks for the specific test result
        student.testresult[testResultIndex].markobtained = markobtained;

        // Save the updated student document
        await student.save();

        return res.json({ status: 200, message: "Marks updated successfully", data: student });
    } catch (error) {
        return res.json({ status: 400, message: "Invalid error", error: error.message });
    }
};



export const attendace = async (req, res) => {
    try {
        const { subjectstatus, date, _id } = req.body;

        // const subject = await Subject.findOne({ subjectname });
        // console.log(subject, "subject");

        // if (!subject) {
        //     return res.json({ status: 401, message: "subject not found" })
        // }

        const findstudent = await Student.findById({ _id });
        console.log(findstudent, "findstudent");

        const existingAttendance = findstudent.studenattendance.find(att => att.date.toDateString() === new Date(date).toDateString());

        if (existingAttendance) {
            return res.json({ status: 401, message: "Attendance already recorded for this student on this date" });
        }

        if (!findstudent) {
            return res.json({ status: 402, message: "Student not found" })
        }

        findstudent.studenattendance.push({ subjectstatus, date });
        console.log(findstudent, "findstudent");

        const attendacestudentdata = await findstudent.save();

        console.log(attendacestudentdata, "attendacestudentdata");
        return res.json({ status: 200, message: "attendance update successfully", attendace: attendacestudentdata });

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const editattendance = async (req, res) => {
    try {
        const { _id, subjectstatus, date } = req.body;

        const findstudent = await Student.findById({ _id });
        console.log(findstudent, "findstudent");

        if (!findstudent) {
            return res.json({ status: 401, message: "student not found" })
        }

        const updateattendance = findstudent.studenattendance;
        console.log(updateattendance, "updateattendance");

        if (!updateattendance) {
            return res.json({ status: 402, message: "studenattendance not found" })
        }

        // for (let i = 0; i < updateattendance.length; i++) {
        //     updateattendance[i].subjectstatus = subjectstatus
        // }

        let attendanceUpdated = false;
        for (let i = 0; i < updateattendance.length; i++) {
            if (new Date(updateattendance[i].date).toDateString() === new Date(date).toDateString()) {
                updateattendance[i].subjectstatus = subjectstatus;
                attendanceUpdated = true;
                break;
            }
        }

        if (!attendanceUpdated) {
            return res.json({ status: 403, message: "Attendance for specified date not found" });
        }


        console.log(findstudent, "update marks")
        await findstudent.save();

        return res.json({ status: 200, message: "attendance edit successfully", findstudent })


    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }

}

export const attendacetrack = async (req, res) => {
    try {
        const { _id } = req.body

        const attendaceupdate = await Student.find({ _id }).populate('batch').populate('course').populate('assignedteacher');

        if (!attendaceupdate) {
            return res.json({ status: 401, message: "student not found" });
        }

        return res.json({ sttus: 200, message: "see attendace track", attendaceupdate: attendaceupdate })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error" })
    }
}


export const getdatacoursewise = async (req, res) => {
    try {
        const { courseId } = req.body;

        const students = await Student.find({ course: courseId }).populate('batch');
        console.log(students, "studentsinfo");

        const batchIds = [...new Set(students.map(student => student.batch._id.toString()))];

        const batches = await Batch.find({ '_id': { $in: batchIds } });
        res.json(batches);
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
};

export const getbatchwisedata = async (req, res) => {
    try {
        const { batchId } = req.body;

        const batch = await Student.find({ batch: batchId }).populate('batch').populate('course').populate('assignedteacher');
        console.log(batch, "batch data");
        res.json(batch)
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }

}


export const createtest = async (req, res) => {
    try {
        const { studentIds, createsubject, date, assignedteacher } = req.body;

        const teacher = await Teacher.findById(assignedteacher);
        if (!teacher) {
            return res.status(403).json({ message: "Teacher not found" });
        }

        const newtest = new Createsubject({
            createsubject: createsubject,
            students: studentIds,
            assignedteacher: teacher._id,
            date: date
        });

        await newtest.save();

        const students = await Student.find({ _id: { $in: studentIds } });

        for (let student of students) {
            if (!student) {
                return res.status(401).json({ status: 401, message: `Student not found` });
            }

            student.createsubject.push(newtest._id);
            await student.save();

            const mailoption = {
                from: `<${process.env.EMAIL_USER}>`,
                to: student.email,
                subject: "New Test Created",
                text: `Dear ${student.name}, a new test for the subject "${createsubject}" has been created for you. Please check your account for details.`,
                html: `<p>Dear ${student.name}, a new test for the subject "<strong>${createsubject}</strong>" has been created for you. Please check your account for details.</p>`
            };

            transporter.sendMail(mailoption, (error, info) => {
                if (error) {
                    console.error('Error sending email:', error);
                } else {
                    console.log('Email sent: %s', info.messageId);
                }
            });
        }

        return res.json({ status: 200, message: "Test created and assigned to students successfully" });

    } catch (error) {
        return res.status(400).json({ status: 400, message: "Invalid error", error: error.message });
    }
};






// message using WP_PHONE_NUMBER

// export const createtest = async (req, res) => {
//     try {
//         const { studentIds, createsubject, date, assignedteacher } = req.body;

//         const teacher = await Teacher.findById(assignedteacher);
//         console.log(teacher, "teacher");

//         if (!teacher) {
//             return res.status(403).json({ message: "Teacher not found" });
//         }

//         const newtest = new Createsubject({
//             createsubject: createsubject,
//             students: studentIds,
//             assignedteacher: teacher._id,
//             date: date
//         });
//         console.log(newtest, "newtest");

//         await newtest.save();

//         // Retrieve students from the database
//         const students = await Student.find({ _id: { $in: studentIds } });

//         // Iterate over students and update each one
//         for (let student of students) {
//             if (!student) {
//                 return res.status(401).json({ status: 401, message: `Student not found` });
//             }

//             // Update student's 'createsubject' array
//             student.createsubject.push(newtest._id);
//             await student.save();

//             // Send WhatsApp message to student
//             const twilioClient = new twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
//             try {
//                 const formattedNumber = student.number.replace(/[\s+\-]/g, ''); // Remove spaces and +
//                 await twilioClient.messages.create({
//                     body: `Dear ${student.name}, a new test has been created for you. Please check your account for details.`,
//                     from: process.env.TWILIO_WP_PHONE_NUMBER,
//                     to: `whatsapp:${formattedNumber}` // Ensure number is in WhatsApp format
//                 });
//                 console.log(`WhatsApp message sent to student ${student.name} with number ${formattedNumber}`);
//             } catch (error) {
//                 console.error(`Error sending WhatsApp message to student ${student.name} with number ${formattedNumber}: ${error.message}`);
//             }

//         }

//         return res.json({ status: 200, message: "Test created and assigned to students successfully" });

//     } catch (error) {
//         return res.status(400).json({ status: 400, message: "Invalid error", error: error.message });
//     }
// };


// message using PHONE_NUMBER

// export const createtest = async (req, res) => {
//     try {
//         const { studentIds, createsubject, date, assignedteacher } = req.body;

//         const teacher = await Teacher.findById(assignedteacher);
//         console.log(teacher, "teacher");

//         if (!teacher) {
//             return res.status(403).json({ message: "Teacher not found" });
//         }

//         const newtest = new Createsubject({
//             createsubject: createsubject,
//             students: studentIds, // Assign the array of student IDs
//             assignedteacher: teacher._id,
//             date: date
//         });
//         console.log(newtest, "newtest");

//         await newtest.save();

//         // Iterate over student IDs and update each student
//         for (let studentId of studentIds) {
//             const findstudent = await Student.findById(studentId);
//             console.log(findstudent, "findstudent");

//             if (!findstudent) {
//                 return res.json({ status: 401, message: `Student with ID ${studentId} not found` });
//             }

//             findstudent.createsubject.push(newtest._id);
//             await findstudent.save();

//             const twilioClient = new Twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
//             twilioClient.messages.create({
//                 body: `Dear student, a new test has been created for you. Please check your account for details.`,
//                 from: process.env.TWILIO_PHONE_NUMBER,
//                 to: findstudent.number
//             }).then(message => console.log(`SMS sent to ${findstudent.phoneNumber}: ${message.sid}`))
//                 .catch(error => console.error(`Error sending SMS to ${findstudent.phoneNumber}: ${error.message}`));
//         }

//         return res.json({ status: 200, message: "Test created and assigned to students successfully" });

//     } catch (error) {
//         return res.json({ status: 400, message: "Invalid error", error: error.message });
//     }
// }


export const subjectstudentdata = async (req, res) => {
    try {
        const { _id } = req.body

        const findstudent = await Student.findById({ _id }).populate({
            path: 'createsubject',
            // options: { sort: { 'date': -1 }, limit: 1 }
        });

        if (!findstudent) {
            return res.json({ status: 402, message: "Student not found" })
        }

        const createsubjectData = findstudent.createsubject;

        return res.send({ createsubjectData })

    } catch (error) {
        return res.status(400).json({ message: "Invalid error", error: error.message });
    }
}

export const studentdetails = async (req, res) => {
    try {

        const { _id } = req.body;

        const findstudentdetails = await Student.findById({ _id }).populate('batch')
            .populate('course')
            .populate('createsubject')
            .populate({
                path: 'testresult',
                populate: {
                    path: 'uploadmarks',
                    model: 'Drive',
                    populate: {
                        path: 'createsubject',
                        model: 'createsubject'
                    }
                }
            });
        console.log(findstudentdetails, "findstudentdetails");

        return res.send(findstudentdetails);

    } catch (error) {
        return res.status(400).json({ message: "Invalid error", error: error.message });
    }
}



// export const multiplestudentattendance = async (req, res) => {
//     try {
//         const { subjectstatus, _id } = req.body;

//         // Ensure _id is an array of student IDs
//         if (!Array.isArray(_id)) {
//             return res.status(400).json({ status: 400, message: "Invalid student IDs. Expected an array." });
//         }

//         // Find and update attendance for each student in the array
//         const updateResults = await Promise.all(_id.map(async (studentId) => {
//             const findstudent = await Student.findById(studentId);
//             if (!findstudent) {
//                 return { status: 401, message: `Student not found with ID: ${studentId}` };
//             }
//             const existingAttendance = findstudent.studenattendance.find(att => att.date.toDateString() === new Date().toDateString());
//             if (existingAttendance) {
//                 return { status: 402, message: "Attendance already recorded for student" };
//             }
//             findstudent.studenattendance.push({ subjectstatus, date: new Date() });
//             return findstudent.save();
//         }));

//         // Check if any update result indicates existing attendance
//         const existingAttendanceResult = updateResults.find(result => result && result.status === 402);
//         if (existingAttendanceResult) {
//             return res.status(402).json(existingAttendanceResult);
//         }

//         // Check results and send appropriate response
//         updateResults.forEach(result => {
//             if (result instanceof Error) {
//                 console.error("Error updating attendance:", result);
//             }
//         });

//         return res.json({ status: 200, message: "Attendance updated successfully" });
//     } catch (error) {
//         console.error("Error updating attendance:", error);
//         return res.status(403).json({ status: 403, message: "Internal server error" });
//     }
// };

export const multiplestudentattendance = async (req, res) => {
    try {
        const { attendanceData } = req.body;

        const promises = attendanceData.map(async (attendance) => {
            const { studentId, status, date } = attendance;

            // Find the student by ID
            const student = await Student.findById(studentId);

            if (!student) {
                return res.json({ status: 401, message: "Student not found" });
            }

            // Check if attendance already recorded for this student on this date
            const existingAttendance = student.studenattendance.find(att => att.date.toDateString() === new Date(date).toDateString());

            if (existingAttendance) {
                return res.json({ status: 402, message: "Attendance already recorded for student" });
            }

            // Update attendance record for the student
            student.studenattendance.push({ subjectstatus: status, date });
            await student.save();

            return res.json({ status: 200, message: "Attendance updated successfully" });
        });

        // Wait for all promises to resolve
        const results = await Promise.all(promises);

        // Check if any error occurred during attendance update
        const errorResult = results.find(result => result.status !== 200);

        if (errorResult) {
            return res.status(errorResult.status).json({ message: errorResult.message });
        }

        return res.json({ status: 200, message: "Attendance updated successfully" })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const multipleperformance = async (req, res) => {
    try {
        const { _id, performancestatus, date, subject } = req.body;

        const findstudent = await Student.findById(_id);
        console.log(findstudent, "findstudent");

        if (!findstudent) {
            return res.status(401).json({ message: "Student not found" });
        }

        const newDate = new Date(date).toDateString();

        const existingperformance = findstudent.performance.find(performance => performance.date.toDateString() === newDate);

        if (existingperformance) {
            return res.status(402).json({ message: "Performance already recorded for this date" });
        }

        findstudent.performance.push({ performancestatus, date: new Date(date), subject });
        console.log(findstudent, "updated student");

        await findstudent.save();

        return res.status(200).json({ message: "Performance updated successfully" });

    } catch (error) {
        return res.status(400).json({ message: "Invalid error", error: error.message });
    }
};


export const markperformance = async (req, res) => {
    try {
        const { _id, performancestatus, date, subject } = req.body;

        const findstudent = await Student.findById(_id);
        console.log(findstudent, "findstudent");

        if (!findstudent) {
            return res.json({ status: 401, message: "student not found" });
        }

        const newPerformanceDate = new Date(date);

        const existingPerformance = findstudent.performance.find(performance => {
            const performanceDate = new Date(performance.date);
            return performanceDate.toDateString() === newPerformanceDate.toDateString();
        });

        if (existingPerformance) {
            return res.json({ status: 402, message: "performance for the given date already exists", findstudent });
        }

        findstudent.performance.push({ performancestatus, date, subject });

        const updateperformance = await findstudent.save();
        console.log(updateperformance, "updateperformance");

        return res.json({ status: 200, message: "performance updated successfully", updateperformance });

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message });
    }
}

export const editperformance = async (req, res) => {

    try {
        const { _id, performancestatus, date } = req.body;

        const findstudent = await Student.findById({ _id });
        console.log(findstudent, "findstudent");

        const updateperformance = findstudent.performance;
        console.log(updateperformance, "updateperformance");

        if (!updateperformance) {
            return res.json({ status: 401, message: "performance not updated" })
        }

        var performanceupdated = false;

        for (var i = 0; i <= updateperformance.length; i++) {
            if (new Date(updateperformance[i].date).toDateString() === new Date(date).toDateString()) {
                updateperformance[i].performancestatus = performancestatus;
                performanceupdated = true;
                break;
            }
        }

        if (!performanceupdated) {
            return res.json({ status: 402, message: "performance not updated for this student" })
        }

        console.log(findstudent, "updated performance")
        await findstudent.save();

        return res.json({ status: 200, message: "performance edited successfully", findstudent })


    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message });
    }

}





















