import bcrypt from "bcrypt"
import Teacher from "../Modal/TeacherSchema.js";
import Student from "../Modal/StudentSchema.js";
import Course from "../Modal/CourseSchema.js";
import jwt from 'jsonwebtoken';

export const teacherregister = async (req, res) => {
    try {
        const { name, email, password, course } = req.body;

        const imagePath = req.file.path;

        const hashpassword = await bcrypt.hash(password, 10)

        const coursename = await Course.findOne({ course });
        console.log(coursename, "coursename");

        const newTeacher = new Teacher({
            name: name,
            email: email,
            password: hashpassword,
            image: imagePath,
            course: coursename
        })
        console.log(newTeacher, "newTeacher")
        await newTeacher.save();

        coursename.teachers.push(newTeacher._id);
        await coursename.save();

        return res.json({ status: 200, message: "Teacher register successfully" })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

export const teacherlogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        const teacherdata = await Teacher.findOne({ email });

        if (!teacherdata) {
            return res.json({ status: 401, message: "email is already present" })
        }
        const passwordcorrect = await bcrypt.compare(password, teacherdata.password);

        if (!passwordcorrect) {
            return res.json({ status: 402, message: "Incorrect password" })
        }

        const course = await Course.findById(teacherdata.course);

        if (!course) {
            return res.json({ status: 402, message: "Course not found" })
        }

        const studentjwt = jwt.sign({ _id: teacherdata._id, role: teacherdata.role, name: teacherdata.name }, process.env.JWT_SECRET);
        console.log(studentjwt, "studentjwt");

        const studentwithoutpassword = { _id: teacherdata._id, role: teacherdata.role, name: teacherdata.name, course: course }
        console.log(studentwithoutpassword, "studentwithoutpassword");

        return res.json({ status: 200, message: "Teacher login successfully", logindata: teacherdata, withoutpass: studentwithoutpassword })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }

}

export const assignedteacher = async (req, res) => {
    try {
        const { name, _id } = req.body

        const studentId = await Student.findById(_id);
        console.log(studentId, "studentId");

        if (!studentId) {
            return res.json({ status: 402, message: "student not found" })
        }

        const teacherinfo = await Teacher.findOne({ name })
        console.log(teacherinfo, "teacherinfo");

        if (!teacherinfo) {
            return res.json({ status: 401, message: "Teacher not found" })
        }

        studentId.assignedteacher = teacherinfo._id;

        const studentdata = await studentId.save();
        console.log(studentdata, "studentdata");
        return res.json({ status: 200, message: "assigned teacher successfully" });


    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const teacherstudentdata = async (req, res) => {
    try {
        const { _id } = req.body;

        const teacherstudentdata = await Student.find({ assignedteacher: _id }).populate('batch').populate('course').populate('assignedteacher');
        console.log(teacherstudentdata, "teacherstudentdata");

        if (!teacherstudentdata) {
            return res.json({ status: 401, message: "teacher not found" })
        }
        return res.json(teacherstudentdata)

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}



