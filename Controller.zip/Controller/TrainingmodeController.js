import Trainingmode from "../Modal/TraningmodeSchema.js"

export const trainingmode = async (req, res) => {
    try {

        const { trainingmode } = req.body;
        console.log(req.body, "reqbody")

        const training = await Trainingmode.findOne({ trainingmode });
        console.log(training, "training");

        if (training) {
            return res.json({ status: 401, message: "training mode is already present" })
        }

        const newtraining = new Trainingmode({
            trainingmode: trainingmode,
        })
        console.log(newtraining, "newtraining");
        await newtraining.save();

        return res.json({ status: 200, message: "trainingmode update successfully" })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}


export const getalltrainingmode = async (req, res) => {
    try {
        const getalltrainingmode = await Trainingmode.find({});
        console.log(getalltrainingmode, "getalltrainingmode");

        if (!getalltrainingmode) {
            return res.json({ status: 401, message: "data not found" })
        }

        res.send(getalltrainingmode)

    } catch (error) {
        return res.json({ status: 400, message: "invalid error", error: error.message })
    }
}

