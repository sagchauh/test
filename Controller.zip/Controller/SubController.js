import Subject from "../Modal/SubSchema.js"

export const subjectenter = async (req, res) => {
    try {
        const { subjectname } = req.body;

        const newSubject = new Subject({
            subjectname: subjectname
        })
        console.log(newSubject, "newSubject");
        await newSubject.save();
        return res.json({ status: 200, message: "subject added successfully", data: newSubject })
    } catch (error) {
        return res.json({ status: 400, message: "invalid error" })
    }

}

export const showallsubject = async (req, res) => {
    try {
        const allsubject = await Subject.find({});
        console.log(allsubject);
        return res.send(allsubject)
    } catch (error) {
        return res.json({ status: 400, message: "invalid error" })
    }
}

